package org.softuni.mobilele.model.enums;

public enum EngineEnum {
    PETROL,DIESEL,ELECTRIC;
}
