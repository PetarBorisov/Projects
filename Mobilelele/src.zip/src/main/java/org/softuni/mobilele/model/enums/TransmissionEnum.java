package org.softuni.mobilele.model.enums;

public enum TransmissionEnum {
    MANUAL,
    AUTOMATIC;
}
