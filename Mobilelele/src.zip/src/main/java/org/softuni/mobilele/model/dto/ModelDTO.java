package org.softuni.mobilele.model.dto;

public record ModelDTO(Long id, String name) {
}
