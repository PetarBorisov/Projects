package org.softuni.mobilele.model.enums;

public enum ModelCategoryEnum {
    CAR,TRUCK,MOTORCYCLE;
}
