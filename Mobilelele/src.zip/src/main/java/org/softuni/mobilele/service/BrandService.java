package org.softuni.mobilele.service;

import org.softuni.mobilele.model.dto.BrandDTO;

import java.util.List;

public interface BrandService {

    List<BrandDTO> getAllBrands();
}
