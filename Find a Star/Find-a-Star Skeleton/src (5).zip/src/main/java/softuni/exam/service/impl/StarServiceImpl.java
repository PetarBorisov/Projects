package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.StarSeedDto;
import softuni.exam.models.entity.Star;
import softuni.exam.repository.StarRepository;
import softuni.exam.service.StarService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Locale;

@Service
public class StarServiceImpl implements StarService {
    public static String STAR_FILE_PATH = "src/main/resources/files/json/stars.json";

    private final StarRepository starRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final Gson gson;


@Autowired
    public StarServiceImpl(StarRepository starRepository, ModelMapper modelMapper, ValidationUtil validationUtil, Gson gson) {
        this.starRepository = starRepository;
    this.modelMapper = modelMapper;
    this.validationUtil = validationUtil;
    this.gson = gson;
}


    @Override
    public boolean areImported() {
        return starRepository.count() > 0;
    }

    @Override
    public String readStarsFileContent() throws IOException {
        return Files.readString(Path.of(STAR_FILE_PATH));
    }

    @Override
    public String importStars() throws IOException {
    StringBuilder stringBuilder = new StringBuilder();

        Arrays.stream(gson.fromJson(readStarsFileContent(), StarSeedDto[].class))
                .filter(starSeedDto -> {
                    boolean isValid = validationUtil.isValid(starSeedDto);
                    if (starRepository.findFirstByName(starSeedDto.getName()).isPresent()) {
                        isValid = false;
                    }
                    stringBuilder.append(isValid ? String.format(Locale.US,"Successfully imported star %s - %.2f light years",
                            starSeedDto.getName(),starSeedDto.getLightYears())
                            : "Invalid star").append(System.lineSeparator()) ;
                    return isValid;

                })
                .map(starSeedDto -> modelMapper.map(starSeedDto, Star.class))
                .forEach(starRepository::save);
        ;

        return stringBuilder.toString();
    }

    @Override
    public String exportStars() {
        return null;
    }
}
