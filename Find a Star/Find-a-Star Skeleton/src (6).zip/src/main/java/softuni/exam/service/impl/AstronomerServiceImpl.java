package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.AstronomerSeedRootDto;
import softuni.exam.models.entity.Astronomer;
import softuni.exam.models.entity.Star;
import softuni.exam.repository.AstronomerRepository;
import softuni.exam.repository.StarRepository;
import softuni.exam.service.AstronomerService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Optional;

@Service
public class AstronomerServiceImpl implements AstronomerService {
    public static String ASTRONOMER_FILE_PATH = "src/main/resources/files/xml/astronomers.xml";

    private final AstronomerRepository astronomerRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final XmlParser xmlParser;
    private final StarRepository starRepository;



@Autowired
    public AstronomerServiceImpl(AstronomerRepository astronomerRepository, ModelMapper modelMapper, ValidationUtil validationUtil, XmlParser xmlParser, StarRepository starRepository) {
        this.astronomerRepository = astronomerRepository;
    this.modelMapper = modelMapper;
    this.validationUtil = validationUtil;
    this.xmlParser = xmlParser;
    this.starRepository = starRepository;
}


    @Override
    public boolean areImported() {
        return astronomerRepository.count() > 0;
    }

    @Override
    public String readAstronomersFromFile() throws IOException {
        return Files.readString(Path.of(ASTRONOMER_FILE_PATH));
    }

    @Override
    public String importAstronomers() throws IOException, JAXBException {
    StringBuilder stringBuilder = new StringBuilder();

   xmlParser
           .fromFile(ASTRONOMER_FILE_PATH, AstronomerSeedRootDto.class)
           .getAstronomers()
           .stream()
           .filter(astronomerSeedDto -> {
               boolean isValid = this.validationUtil.isValid(astronomerSeedDto);

               Optional<Astronomer> byFullNames = this.astronomerRepository
                       .findFirstByFirstNameAndLastName(astronomerSeedDto.getFirstName(),astronomerSeedDto.getLastName());

               if (byFullNames.isPresent()){
                   isValid = false;
               }
               Optional<Star> starById = this.starRepository
                       .findById(astronomerSeedDto.getObservingStarId());
               if (starById.isEmpty()) {
                   isValid = false;

               }
               stringBuilder.append(isValid ? String.format(Locale.US,"Successfully imported astronomer %s %s - %.2f",
                       astronomerSeedDto.getFirstName(),astronomerSeedDto.getLastName(),
                       astronomerSeedDto.getAverageObservationHours())
                       : "Invalid astronomer")
                       .append(System.lineSeparator());
               return isValid;
           })
           .map(astronomerSeedDto -> {
               Astronomer astronomer = modelMapper.map(astronomerSeedDto,Astronomer.class);
               Optional<Star> starById = this.starRepository
                       .findById(astronomerSeedDto.getObservingStarId());
                    astronomer.setStar(starById.get());
               return astronomer;
           })
           .forEach(this.astronomerRepository::save);
   return stringBuilder.toString();
    }
}
