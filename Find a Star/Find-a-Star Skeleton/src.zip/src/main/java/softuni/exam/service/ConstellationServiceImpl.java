package softuni.exam.service;

import org.springframework.stereotype.Service;

import java.io.IOException;
@Service
public class ConstellationServiceImpl implements ConstellationService {
    @Override
    public boolean areImported() {
        return false;
    }

    @Override
    public String readConstellationsFromFile() throws IOException {
        return null;
    }

    @Override
    public String importConstellations() throws IOException {
        return null;
    }
}
